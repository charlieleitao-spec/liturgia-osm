import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(new URL('..', import.meta.url).pathname);
const www = path.join(root, 'www');
const html = fs.readFileSync(path.join(www, 'index.html'), 'utf8');
const sw = fs.readFileSync(path.join(www, 'sw.js'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(www, 'manifest.webmanifest'), 'utf8'));
const required = ['index.html', 'sw.js', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png'];
const errors = [];

for (const file of required) {
  if (!fs.existsSync(path.join(www, file)) || fs.statSync(path.join(www, file)).size === 0) errors.push(`Arquivo ausente ou vazio: ${file}`);
}
for (const marker of ['Calendário OSM', 'Santoral', 'Orações', 'Modo celebração', 'conteúdo disponível offline', 'Missa do dia', 'Fonte online com cópia offline']) {
  if (!html.includes(marker)) errors.push(`Recurso não encontrado: ${marker}`);
}
for (const file of required) {
  if (file !== 'sw.js' && !sw.includes(`'./${file}'`) && file !== 'index.html') errors.push(`Arquivo não incluído no cache: ${file}`);
}
if (!sw.includes("'./index.html'")) errors.push('index.html não incluído no cache offline.');
if (manifest.start_url !== './' || manifest.display !== 'standalone') errors.push('Manifesto PWA incompleto.');
if (html.includes('�')) errors.push('Foi encontrado caractere de substituição no conteúdo.');

const scripts = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)].map(match => match[1]).filter(Boolean);
scripts.forEach((script, index) => {
  try { new Function(script); } catch (error) { errors.push(`Erro de sintaxe no script ${index + 1}: ${error.message}`); }
});

const external = [...new Set([...html.matchAll(/https?:\/\/[^"'\s<]+/g)].map(match => match[0]))];
const allowedExternal = external.filter(url => /youtube\.com|instagram\.com|liturgia\.up\.railway\.app/.test(url));
if (external.length !== allowedExternal.length) errors.push(`Dependências externas inesperadas: ${external.filter(url => !allowedExternal.includes(url)).join(', ')}`);

if (errors.length) {
  console.error(errors.join('\n'));
  process.exit(1);
}
console.log(JSON.stringify({ status: 'ok', version: '4.9.2', cachedFiles: required.length, externalLinks: allowedExternal.length, scripts: scripts.length }, null, 2));
