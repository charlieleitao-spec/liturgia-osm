import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(new URL('..', import.meta.url).pathname);
const www = path.join(root, 'www');
const html = fs.readFileSync(path.join(www, 'index.html'), 'utf8');
const sw = fs.readFileSync(path.join(www, 'sw.js'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(www, 'manifest.webmanifest'), 'utf8'));
const required = ['index.html', 'servite.html', 'data/santoral.json', 'data/oficios-osm.json', 'sw.js', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png'];
const errors = [];

for (const file of required) {
  if (!fs.existsSync(path.join(www, file)) || fs.statSync(path.join(www, file)).size === 0) errors.push(`Arquivo ausente ou vazio: ${file}`);
}
for (const marker of ['Calendário OSM', 'Santoral', 'Orações', 'Modo celebração', 'conteúdo disponível offline', 'Missa do dia', 'Fonte online com cópia offline', 'servite.html']) {
  if (!html.includes(marker)) errors.push(`Recurso não encontrado: ${marker}`);
}
for (const file of required) {
  if (file !== 'sw.js' && !sw.includes(`./${file}`) && file !== 'index.html') errors.push(`Arquivo não incluído no cache: ${file}`);
}
if (!sw.includes('./index.html')) errors.push('index.html não incluído no cache offline.');
if (manifest.start_url !== './' || manifest.display !== 'standalone') errors.push('Manifesto PWA incompleto.');
if (html.includes('�')) errors.push('Foi encontrado caractere de substituição no conteúdo.');

const serviteHtml = fs.readFileSync(path.join(www, 'servite.html'), 'utf8');
const scripts = [html, serviteHtml].flatMap(source => [...source.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)].map(match => match[1]).filter(Boolean));
scripts.forEach((script, index) => {
  try { new Function(script); } catch (error) { errors.push(`Erro de sintaxe no script ${index + 1}: ${error.message}`); }
});

const santoral = JSON.parse(fs.readFileSync(path.join(www, 'data/santoral.json'), 'utf8'));
const oficios = JSON.parse(fs.readFileSync(path.join(www, 'data/oficios-osm.json'), 'utf8'));
for (const key of Object.keys(oficios)) if (!santoral[Number(key)]) errors.push(`Ofício sem celebração correspondente: ${key}`);
const generated = fs.readdirSync(www, { recursive: true, withFileTypes: true }).filter(entry => entry.isFile()).map(entry => path.join(entry.parentPath || entry.path, entry.name));
for (const file of generated) {
  const size = fs.statSync(file).size;
  if (size > 2 * 1024 * 1024) errors.push(`Arquivo excede 2 MB: ${path.relative(www, file)} (${size} bytes)`);
  if (/\.(?:html|js|css)$/i.test(file)) {
    const text = fs.readFileSync(file, 'utf8');
    if (/base64,[A-Za-z0-9+/=]{65536,}/.test(text) || /[A-Za-z0-9+/=]{65536,}/.test(text)) errors.push(`Base64 grande incorporado em ${path.relative(www, file)}`);
  }
}
if (html.includes('SERVITE_DOC_B64') || html.includes('srcdoc=')) errors.push('Documento Servita voltou a ser incorporado no index.html.');

const external = [...new Set([...html.matchAll(/https?:\/\/[^"'\s<]+/g)].map(match => match[0]))];
const allowedExternal = external.filter(url => /youtube\.com|instagram\.com|liturgia\.up\.railway\.app/.test(url));
if (external.length !== allowedExternal.length) errors.push(`Dependências externas inesperadas: ${external.filter(url => !allowedExternal.includes(url)).join(', ')}`);

if (errors.length) {
  console.error(errors.join('\n'));
  process.exit(1);
}
console.log(JSON.stringify({ status: 'ok', version: '4.9.3', cachedFiles: required.length, externalLinks: allowedExternal.length, scripts: scripts.length, indexBytes: fs.statSync(path.join(www, 'index.html')).size, serviteBytes: fs.statSync(path.join(www, 'servite.html')).size, santoralEntries: santoral.length, officeEntries: Object.keys(oficios).length }, null, 2));
