package com.liturgia_osm.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
