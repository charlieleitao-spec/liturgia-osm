import { cp, mkdir, rm } from "node:fs/promises";

await rm("www", { recursive: true, force: true });
await mkdir("www", { recursive: true });
await cp("santoral-osm-5-1 (7).html", "www/index.html");
await cp("sw.js", "www/sw.js");
await cp("manifest.webmanifest", "www/manifest.webmanifest");
await cp("icon-192.png", "www/icon-192.png");
await cp("icon-512.png", "www/icon-512.png");

console.log("Aplicacao web preparada em www/.");
